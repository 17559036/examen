// Объект для обновления существующего элемента
export class UpdateItemDtoWithId {
  id: string; 
  name: string;
  description: string;
}
