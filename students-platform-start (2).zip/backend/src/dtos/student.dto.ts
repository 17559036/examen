// Свойства, которые можно использовать для передачи данных по студентам
export class StudentDto {
  name?: string;
  surname?: string;
  groupName?: string;
  address?: string;
  age?: number;
}