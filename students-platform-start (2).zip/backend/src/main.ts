import { NestFactory } from '@nestjs/core';
import { AppModule } from './modules/app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule, { cors: true }); // Создаем экземпляр Nest приложения
  
  const PORT = process.env.PORT || 3000; // Порт сервера

  await app.listen(PORT); // Запуск приложения
}

bootstrap();

